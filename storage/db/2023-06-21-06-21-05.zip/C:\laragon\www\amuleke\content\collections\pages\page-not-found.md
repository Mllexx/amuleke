---
id: 059d4d8d-fc60-49f8-8823-7da10549e84e
blueprint: page
title: 'Page not found'
page_builder:
  -
    article:
      -
        type: heading
        attrs:
          level: 1
        content:
          -
            type: text
            text: '404 Page not found'
      -
        type: paragraph
        content:
          -
            type: text
            text: 'The page you requested is not available (anymore).'
    type: article
    enabled: true
seo_noindex: true
seo_nofollow: false
seo_canonical_type: entry
sitemap_change_frequency: weekly
sitemap_priority: 0.5
updated_by: 66c6ff90-a9a2-42ba-a4e1-c0872e344786
updated_at: 1646921434
---
