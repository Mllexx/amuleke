<ul class="row">
    <?php if( isset($publications) && (!is_null($publications)) && (is_object($publications)) ): ?>
         <?php $__currentLoopData = $publications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post_id => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li class="col-sm-6 col-xs-12 col-lg-3">
            <div class="image">
                <a href="https://medium.com/@amuleke/<?php echo e($post->uniqueSlug); ?>"  target = "_blank">
                    <!--<img src="https://miro.medium.com/fit/c/300/180/<?php echo e($post->virtuals->previewImage->imageId); ?>">-->
                        <?php if( isset($post->virtuals->previewImage->imageId) && $post->virtuals->previewImage->imageId !== '' ): ?>
                            <img class="medium-article-image" src="https://miro.medium.com/max/180/<?php echo e($post->virtuals->previewImage->imageId); ?>">
                        <?php else: ?>
                            <img class="medium-article-image" src="<?php echo e(asset('img/quill.png')); ?>" width="100px">
                        <?php endif; ?>
                </a>
            </div>
            <h5>
                <a href="https://medium.com/@amuleke/<?php echo e($post->uniqueSlug); ?>" target = "_blank"><?php echo e($post->title); ?></a>
            </h5>
            <p>
                <?php echo e($post->content->subtitle); ?>

            </p>
         </li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <h3>No articles found</h3>
    <?php endif; ?>
</ul>
<?php /**PATH C:\laragon\www\amuleke\resources\views/home/medium-articles.blade.php ENDPATH**/ ?>