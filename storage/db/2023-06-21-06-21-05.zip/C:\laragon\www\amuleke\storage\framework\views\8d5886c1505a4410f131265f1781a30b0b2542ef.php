<div id="footer" class="px-0 pt-5 pb-0 content-segment">
    <div class="row text-start px-0">

    </div>
    <div class="row">
        <p class="pt-4 pb-0">
        <div class="col">
            <ul id="social-icon-links" class="px-1">
                <li class="px-0 py-3">
                    <a href="https://www.linkedin.com/in/andrew-muleke-b436676a/"><i class="fa-brands fa-linkedin-in"></i></a>
                </li>
                <li class="px-2 py-3">
                    <a href="https://github.com/Mllexx"><i class="fa-brands fa-github"></i></a>
                </li>
                <!--
                <li class="px-2 py-3">
                    <a href="#"><i class="fa-brands fa-twitter"></i></a>
                </li>
                -->
                <li class="px-2 py-3">
                    <a href="https://amuleke.medium.com/"><i class="fa-brands fa-medium"></i></a>
                </li>
            </ul>
        </div>
        </p>
        <p class="pt-4 pb-0"> Copyright 	&copy; <?php echo e(Date('Y')); ?>. All rights reserved</p>
    </div>
</div>
<?php /**PATH C:\laragon\www\amuleke\resources\views/components/footer.blade.php ENDPATH**/ ?>