Inquiry from: {{ $name }}
<p> Email: {{ $email }} </p>
<p> Budget: {{ $email }} </p>
<p> Description: {{ $description }} </p>
