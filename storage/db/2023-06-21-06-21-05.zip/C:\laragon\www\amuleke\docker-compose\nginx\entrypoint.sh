#!/usr/bin/env bash
/usr/bin/supervisord