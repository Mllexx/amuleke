CREATE database amuleke;
