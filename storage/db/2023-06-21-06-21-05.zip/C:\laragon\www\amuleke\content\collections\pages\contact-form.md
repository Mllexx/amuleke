---
id: 5c526dbf-9dd7-4c52-98d8-54e00ebddfb6
blueprint: page
title: 'Contact form'
updated_by: 9be3d58e-745d-4669-9a70-21c4c5049b89
updated_at: 1627566855
seo_noindex: false
seo_nofollow: false
seo_canonical_type: entry
sitemap_change_frequency: weekly
sitemap_priority: 0.5
page_builder:
  -
    title: 'A contact form'
    text: 'This form works with static caching. Both the receiver and the owner of the website will receive a styled e-mail. Forms are dynamic, so just add a field to the forms blueprint and it will work.'
    form: contact
    type: form
    enabled: true
---
